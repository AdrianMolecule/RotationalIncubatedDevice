#include <Arduino.h>
#include <WiFi.h>
#include "Web.h"
#include "Model.h"
#include "pass.h"  // Contains readSsid() and readPassword()
#include <SPIFFS.h>

Model model;  // Global model instance
Web web;      // Web server and WebSocket handler

// Forward declaration of handleSerial
void handleSerial();

void setup() {
    Serial.begin(115200);
    delay(1000);
    
    // Initialize SPIFFS and load model
    if (!SPIFFS.begin(true)) {
        Serial.println("Failed to mount SPIFFS, starting with empty model.");
    }
    model.loadFromSPIFFS();

    // Connect to WiFi
    Serial.print("Connecting to WiFi: ");
    Serial.println(readSsid());
    WiFi.begin(readSsid(), readPassword());
    while (WiFi.status() != WL_CONNECTED) {
        delay(500);
        Serial.print(".");
    }
    Serial.println();
    Serial.print("Connected! IP: ");
    Serial.println(WiFi.localIP());

    // Start web server
    web.begin();

    Serial.println("Setup complete.");
}

void loop() {
    // Handle web server and WebSocket clients
    web.loop();

    // Handle serial input to update model
    handleSerial();
}

// Reads lines from Serial to update model fields
void handleSerial() {
    static String inputBuffer = "";
    while (Serial.available()) {
        char c = Serial.read();
        if (c == '\n') {
            inputBuffer.trim();
            if (inputBuffer.length() > 0) {
                model.handleSerialInput(inputBuffer);
                model.saveToSPIFFS();
                web.updateClientValues();
            }
            inputBuffer = "";
        } else {
            inputBuffer += c;
        }
    }
}

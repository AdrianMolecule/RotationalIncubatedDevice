#pragma once
#include <Arduino.h>
#include <vector>
#include "Field.h"

/*
 * Model class represents the collection of fields.
 * Provides methods to manipulate fields, persist/load JSON, handle Serial input, and reset.
 */
class Model {
private:
    std::vector<Field> fields;

public:
    Model();
    void addField(const Field& field);
    void deleteField(const String& name);
    Field* getField(const String& name);
    void setFieldValue(const String& name, const String& value);

    void handleSerialInput(const String& inputLine);

    void saveToSPIFFS();
    void loadFromSPIFFS();
    void resetToInitialValues();
    // Convert model fields to JSON string
    String toJsonString() const;
    // Update model fields from a JSON string
    void handleJson(const String& jsonString);
    const std::vector<Field>& getFields() const { return fields; }
};

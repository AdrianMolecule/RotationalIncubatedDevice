#pragma once
#include <Arduino.h>

// WebPageIndex class holds the HTML of the main index page
class WebPageIndex {
public:
    static const char* html;  // Declare static HTML member
};

#pragma once
#include <Arduino.h>

/*
 * Field class represents a single data field in the model.
 * It has a name, type, id, value, description, and an initial value.
 */
class Field {
private:
    String name;
    String type;
    String id;
    String value;
    String description;
    String initialValue;

public:
    Field() {}

    Field(const String& name, const String& type, const String& id,
          const String& value, const String& description)
        : name(name), type(type), id(id), value(value), description(description), initialValue(value) {}

    // Getters
    String getName() const { return name; }
    String getType() const { return type; }
    String getId() const { return id; }
    String getValue() const { return value; }
    String getDescription() const { return description; }
    String getInitialValue() const { return initialValue; }

    // Setter
    void setValue(const String& val) { value = val; }
};

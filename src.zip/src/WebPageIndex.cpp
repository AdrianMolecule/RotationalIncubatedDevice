#include "WebPageIndex.h"

// Define the static HTML member
const char* WebPageIndex::html = R"rawliteral(
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>AD</title>
<script>
var ws;

function initWebSocket() {
    ws = new WebSocket('ws://' + location.host + '/ws');
    ws.onmessage = function(event) {
        console.log('WS message', event.data);
        updateFields(JSON.parse(event.data));
    };
}

function updateFields(fields) {
    let table = document.getElementById('fieldsTable');
    table.innerHTML = '<tr><th>Name</th><th>Type</th><th>ID</th><th>Value</th><th>Description</th></tr>';
    fields.forEach(f => {
        let row = table.insertRow();
        row.insertCell(0).innerText = f.name;
        row.insertCell(1).innerText = f.type;
        row.insertCell(2).innerText = f.id;
        let valCell = row.insertCell(3);
        valCell.innerHTML = `<input value="${f.value}" onchange="changeValue('${f.name}', this.value)">`;
        row.insertCell(4).innerText = f.description;
    });
}

function changeValue(name, value) {
    ws.send(JSON.stringify({ action: 'update', name: name, value: value }));
}

function resetValues() {
    ws.send(JSON.stringify({ action: 'reset' }));
}

window.onload = () => { initWebSocket(); };
</script>
</head>
<body>
<h2>AD</h2>
<nav>
    <a href="/metadata">Metadata</a>
</nav>
<table border="1" id="fieldsTable"></table>
<button onclick="resetValues()">Reset to Initial Values</button>
</body>
</html>
)rawliteral";

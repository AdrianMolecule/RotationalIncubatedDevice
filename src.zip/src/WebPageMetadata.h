#pragma once
#include <Arduino.h>

// WebPageMetadata class holds the HTML of the metadata page
class WebPageMetadata {
public:
    static const char* metadataHtml;  // Declare static HTML member
};

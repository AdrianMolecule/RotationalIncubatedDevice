#ifndef AdrianOsPcbPins_H_
#define AdrianOsPcbPins_H_
#include "Arduino.h"
#include "Pins.h"

class AdrianOsPcbPins:public Pins {
    public:
    AdrianOsPcbPins();// Constructor declaration
};

#endif /* AdrianOsPcbPins_H_ */
#pragma once

#include "Model.h"
#include <SPIFFS.h>
#include <ArduinoJson.h>

Model::Model() {
    // Optionally initialize default fields here
    // Example:
    // fields.push_back(Field("F1", "int", "1", "0", "Field 1 description"));
}

void Model::addField(const Field& field) {
    fields.push_back(field);
}

void Model::deleteField(const String& name) {
    for (auto it = fields.begin(); it != fields.end(); ++it) {
        if (it->getName() == name) {
            fields.erase(it);
            Serial.printf("Deleted field '%s'\n", name.c_str());
            return;
        }
    }
}

Field* Model::getField(const String& name) {
    for (auto &f : fields) {
        if (f.getName() == name) return &f;
    }
    return nullptr;
}

void Model::setFieldValue(const String& name, const String& value) {
    Field* f = getField(name);
    if (f) {
        f->setValue(value);
    }
}

// --------------------- Serial Handling ---------------------
void Model::handleSerialInput(const String& inputLine) {
    int eqPos = inputLine.indexOf('=');
    if (eqPos < 0) return; // Invalid format

    String name = inputLine.substring(0, eqPos);
    String value = inputLine.substring(eqPos + 1);

    Field* f = getField(name);
    if (f) {
        f->setValue(value);
        Serial.printf("Updated field '%s' to '%s' via Serial\n", name.c_str(), value.c_str());
    } else {
        Serial.printf("Field '%s' not found in model\n", name.c_str());
    }
}

// --------------------- JSON Persistence ---------------------
void Model::saveToSPIFFS() {
    JsonDocument doc();
    JsonArray arr = doc.to<JsonArray>();

    for (auto &f : fields) {
        JsonObject obj = arr.add<JsonObject>();
        obj["name"] = f.getName();
        obj["type"] = f.getType();
        obj["id"] = f.getId();
        obj["value"] = f.getValue();
        obj["description"] = f.getDescription();
    }

    File file = SPIFFS.open("/model.json", FILE_WRITE);
    if (!file) {
        Serial.println("Failed to open /model.json for writing");
        return;
    }
    serializeJson(doc, file);
    file.close();
}

void Model::loadFromSPIFFS() {
    if (!SPIFFS.exists("/model.json")) {
        Serial.println("/model.json does not exist, starting with empty model");
        return;
    }

    File file = SPIFFS.open("/model.json", FILE_READ);
    if (!file) {
        Serial.println("Failed to open /model.json for reading");
        return;
    }

    DynamicJsonDocument doc(2048);
    DeserializationError err = deserializeJson(doc, file);
    file.close();
    if (err) {
        Serial.println("Failed to parse /model.json");
        return;
    }

    fields.clear();
    JsonArray arr = doc.as<JsonArray>();
    for (JsonObject obj : arr) {
        fields.push_back(Field(
            obj["name"].as<String>(),
            obj["type"].as<String>(),
            obj["id"].as<String>(),
            obj["value"].as<String>(),
            obj["description"].as<String>()
        ));
    }
}

// --------------------- Reset ---------------------
void Model::resetToInitialValues() {
    for (auto &f : fields) {
        f.setValue(f.getInitialValue());
    }
}
String Model::toJsonString() const {
    DynamicJsonDocument doc(2048);
    JsonArray arr = doc.to<JsonArray>();

    for (const auto &f : fields) {
        JsonObject obj = arr.add<JsonObject>();
        obj["name"] = f.getName();
        obj["type"] = f.getType();
        obj["id"] = f.getId();
        obj["value"] = f.getValue();
        obj["description"] = f.getDescription();
    }

    String output;
    serializeJson(doc, output);
    return output;
}
#pragma once
enum {
    STEPS200 = 200,
    STEPS400 = 400,
    STEPS800 = 800,
    STEPS1600 = 1600,
    STEPS3200 = 3200,
    STEPS6400 = 6400,
};
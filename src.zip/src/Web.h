#pragma once
#include <WebServer.h>
#include <WebSocketsServer.h>

class Web {
public:
    static void begin();
    static void loop();
    static void updateClientValues();
    static void onWsEvent(uint8_t num, WStype_t type, uint8_t * payload, size_t length);

private:
    static WebServer server;
    static WebSocketsServer webSocket;
};

#include "WebPageMetadata.h"

// Define the static HTML member
const char* WebPageMetadata::metadataHtml = R"rawliteral(
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Metadata</title>
<script>
var ws;
function initWebSocket() {
    ws = new WebSocket('ws://' + location.host + '/ws');
    ws.onmessage = function(event) {
        console.log('WS message', event.data);
        loadFields();
    };
}
function addField() {
    const name = document.getElementById('fieldName').value;
    const type = document.getElementById('fieldType').value;
    const id = document.getElementById('fieldId').value;
    const value = document.getElementById('fieldValue').value;
    const description = document.getElementById('fieldDescription').value;

    if(!name) return;

    ws.send(JSON.stringify({
        action: 'add',
        name: name,
        type: type,
        id: id,
        value: value,
        description: description
    }));

    document.getElementById('fieldName').value = '';
    document.getElementById('fieldType').value = '';
    document.getElementById('fieldId').value = '';
    document.getElementById('fieldValue').value = '';
    document.getElementById('fieldDescription').value = '';
}

function deleteField(name) {
    ws.send(JSON.stringify({ action: 'delete', name: name }));
}

function loadFields() {
    fetch('/model.json')
    .then(resp => resp.json())
    .then(data => {
        let table = document.getElementById('fieldsTable');
        table.innerHTML = '';
        data.forEach(f => {
            let row = table.insertRow();
            row.insertCell(0).innerText = f.name;
            row.insertCell(1).innerText = f.type;
            row.insertCell(2).innerText = f.id;
            row.insertCell(3).innerText = f.value;
            row.insertCell(4).innerText = f.description;
            let del = row.insertCell(5);
            let btn = document.createElement('button');
            btn.innerText = 'Delete';
            btn.onclick = () => deleteField(f.name);
            del.appendChild(btn);
        });
    });
}

window.onload = () => { initWebSocket(); loadFields(); };
</script>
</head>
<body>
<h2>Metadata Page</h2>
<table border="1" id="fieldsTable"></table>

<h3>Add Field</h3>
<label>Name: <input id="fieldName"></label><br>
<label>Type: <input id="fieldType"></label><br>
<label>ID: <input id="fieldId"></label><br>
<label>Value: <input id="fieldValue"></label><br>
<label>Description: <input id="fieldDescription"></label><br>
<button onclick="addField()">Add Field</button>
</body>
</html>
)rawliteral";

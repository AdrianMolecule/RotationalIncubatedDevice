#ifndef AdrianOsMksPins_H_
#define AdrianOsMksPins_H_
#include "Arduino.h"
#include "Pins.h"

class AdrianOsMksPins:public Pins {
    public:
    AdrianOsMksPins();// Constructor declaration
};

#endif /* AdrianOsMksPins_H_ */
#pragma once

#include "Web.h"
#include "WebPageIndex.h"
#include "WebPageMetadata.h"
#include "Model.h"
#include <WiFi.h>
#include <SPIFFS.h>
#include <ESPmDNS.h>

extern Model model;

// Define static members
WebServer Web::server(80);
WebSocketsServer Web::webSocket(81);

void Web::begin() {
    server.on("/", HTTP_GET, []() {
        server.send(200, "text/html", WebPageIndex::html);
    });

    server.on("/metadata", HTTP_GET, []() {
        server.send(200, "text/html", WebPageMetadata::metadataHtml);
    });

    server.on("/model.json", HTTP_GET, []() {
        server.send(200, "application/json", model.toJsonString());
    });

    server.begin();
    webSocket.begin();
    webSocket.onEvent(onWsEvent);

    if (!MDNS.begin("ad")) {
        Serial.println("Error setting up MDNS responder!");
    } else {
        Serial.println("mDNS responder started at http://ad.local/");
    }
}

void Web::loop() {
    server.handleClient();
    webSocket.loop();
}

void Web::onWsEvent(uint8_t num, WStype_t type, uint8_t * payload, size_t length) {
    if(type == WStype_TEXT) {
        payload[length] = 0;
        String msg = (char*)payload;
        Serial.printf("WS received: %s\n", msg.c_str());
        model.handleJson(msg);
        model.saveToSPIFFS();
        updateClientValues();
    }
}

void Web::updateClientValues() {
    String json = model.toJsonString();
    webSocket.broadcastTXT(json);
}
void Model::handleJson(const String& jsonString) {
    JsonDocument doc();
    DeserializationError err = deserializeJson(doc, jsonString);
    if (err) {
        Serial.println("Failed to parse JSON in handleJson()");
        return;
    }

    JsonArray arr = doc.as<JsonArray>();
    for (JsonObject obj : arr) {
        String name = obj["name"].as<String>();
        String value = obj["value"].as<String>();
        setFieldValue(name, value);  // Uses existing setter
        Serial.printf("Updated field '%s' to '%s' via JSON\n", name.c_str(), value.c_str());
    }
}

